# RSS Visualizer Screensaver v1.1.0

A modern Windows screensaver that displays live RSS news headlines in an elegant, ambient visualization inspired by Apple's legacy RSS Visualizer.

## What's New in v1.1.0

🐛 **Critical Fix**: Resolved WebView2 initialization issues when running under restricted security contexts
- Implements multi-location fallback for WebView2 user data folder
- Tests write permissions before selecting location
- Fixes "Access is denied (0x80070005)" error when triggered by Windows
- Now works reliably when launched from OS screensaver settings

## Features

- 📰 **Live RSS Feed Display** - Shows headlines from multiple RSS/Atom feeds
- 🎨 **Beautiful Design** - Cool blue gradient with translucent glass cards
- ☁️ **Word Cloud** - Dynamic word cloud showing trending topics
- 🎯 **Smart Content** - Source-balanced article selection and age filtering
- ⚙️ **Fully Configurable** - Customize feeds, timing, colors, and appearance
- 🚫 **Custom Word Filters** - Exclude specific words from the word cloud

## Installation

### Quick Install (Recommended)

1. **Run the installer**:
   - Right-click `Install.bat` and select "Run as administrator"
   - Follow the prompts

   **OR manually**:

2. **Copy and rename**:
   - Copy `RssVisualizerScreensaver.exe` to `C:\Windows\System32\`
   - Rename it to `RssVisualizerScreensaver.scr`

3. **Configure**:
   - Right-click Desktop → Personalize → Lock screen → Screen saver settings
   - Select "RssVisualizerScreensaver" from the dropdown
   - Click "Settings" to configure feeds and options
   - Click "Preview" to test

## Usage

### Command Line Options

- `/s` - Run screensaver (full-screen mode)
- `/p [hwnd]` - Preview mode (in settings dialog)
- `/c` - Configuration dialog

### Configuration

Click "Settings" in the Windows screensaver settings to configure:

**RSS Feeds**:
- Add/remove RSS or Atom feed URLs
- Default feeds: AP News, BBC, Washington Post, NPR, ESPN, CBS Sports

**Timing**:
- Article display time (default: 12 seconds)
- Feed refresh interval (default: 15 minutes)
- Maximum article age (default: 48 hours)

**Content**:
- Items per feed (default: 24)
- Animation speed multiplier (default: 1.0)

**Word Cloud**:
- Custom excluded words (comma-separated)
- Default exclusions: sports terms, generic words

**Appearance**:
- Font sizes for main card and background
- Background gradient CSS
- Text colors (CSS format)

## Default Settings

The screensaver comes pre-configured with:

- 6 news feeds (3 general news + 3 sports)
- 24 articles per feed for balanced content mix
- 48-hour article freshness window
- Word cloud with 14 custom excluded words
- Cool blue gradient background
- 12-second article display time

## Configuration File

Settings are stored in:
```
%APPDATA%\RssVisualizerScreensaver\config.json
```

You can edit this file directly or use the Settings dialog.

## Technical Details

- **Framework**: .NET 8.0 Windows
- **Rendering**: WebView2 (HTML/CSS/JavaScript)
- **RSS Parsing**: System.ServiceModel.Syndication with DTD support
- **Self-Contained**: No .NET runtime installation required

## Troubleshooting

**Screensaver doesn't start**:
- Ensure the file is named `.scr` or use the `/s` flag
- Check Windows Event Viewer for errors
- Review logs at `C:\Windows\Temp\rss_viz.log`

**Feeds not loading**:
- Check your internet connection
- Verify feed URLs are accessible
- Some feeds may require specific user agents or have rate limits
- Check the log file for feed-specific errors

**Word cloud shows unwanted words**:
- Open Settings → Word Cloud
- Add words to exclude (comma-separated)
- Words are case-insensitive

**Performance issues**:
- Reduce Items per feed (try 10-15 instead of 24)
- Increase refresh interval
- Reduce animation speed to 0.5 or 0.75

## Exit Screensaver

- Move mouse
- Click anywhere
- Press any key
- Touch screen (if touchscreen enabled)

## Requirements

- Windows 10/11 (64-bit)
- WebView2 Runtime (usually pre-installed on Windows 11)
- Internet connection for RSS feeds

## Version History

### 1.0.0 (November 2025)
- Initial release
- RSS/Atom feed support with DTD parsing
- Dynamic word cloud with source balancing
- Configurable settings UI
- Custom stop words for word cloud
- Per-source article limiting
- Random card positioning
- Mouse/keyboard exit detection
- Article age filtering
- Background scrolling headlines

## License

Created as a faithful recreation of Apple's legacy RSS Visualizer for Windows.

## Credits

Design and motion inspired by the original Apple RSS Visualizer screensaver.
